﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using System.Text;

namespace CHttpListener
{
    public enum HttpLogLevel {LogNone = 4, LogError = 3, LogWarning = 2, LogInfo = 1};

    public interface IHttpLog
    {
        void LogText(HttpLogLevel level, string text);
        void LogRequest(HttpLogLevel level, HttpListenerRequest request);
    }

    public class CHttpLogConsole : IHttpLog
    {
        public void LogText(HttpLogLevel level, string text)
        {
            DateTime now = DateTime.Now;
            string levelText;
            string threadId = Thread.CurrentThread.ManagedThreadId.ToString();
            switch (level)
            {
                case HttpLogLevel.LogError:
                    levelText = "-";
                    break;
                case HttpLogLevel.LogWarning:
                    levelText = "!";
                    break;
                default:
                    levelText = " ";
                    break;                       
            }
            Console.WriteLine(levelText + now.ToShortDateString() + " " + now.ToShortTimeString() + " " + threadId + " " + text);
        }
        public void LogRequest(HttpLogLevel level, HttpListenerRequest request)
        {
        }
    }
}
